function start(song)
strumLine2Visible = true
strumLine1Visible = true
showOnlyStrums = false

end

function update (elapsed)
if curStep >= 155 and curStep < 156 then
setCamZoom(1.5)

end

if curStep >= 188 and curStep < 192 then
setCamZoom(1.5)

end

if curStep >= 412 and curStep < 413 then
setCamZoom(1.5)

end

if curStep >= 444 and curStep < 448 then
setCamZoom(1.5)

end

if curStep >= 668 and curStep < 669 then
setCamZoom(1.5)

end

if curStep >= 700 and curStep < 704 then
setCamZoom(1.5)

end

if curStep >= 796 and curStep < 797 then
setCamZoom(1.5)

end

if curStep >= 828 and curStep < 832 then
setCamZoom(1.5)

end
end
	
function beatHit(beat) -- do nothing

end

function stepHit (step) -- do nothing

end